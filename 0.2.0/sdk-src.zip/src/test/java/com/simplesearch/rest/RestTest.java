package com.simplesearch.rest;


import static org.junit.Assert.assertTrue;

import java.io.UnsupportedEncodingException;

import org.apache.commons.lang.StringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.simplesearch.Rest;
import com.simplesearch.utils.HttpRequest;

/**
 * rest all test
 * @author simplesearch
 */
public class RestTest {
	Logger logger = LoggerFactory.getLogger(RestTest.class);
	public static final String BASE_URL = "http://localhost";
	
	public static final String INDEX = "default";
	public static final String SUGGEST_INDEX = "default-suggest";
	
	static String INDEX_URL = BASE_URL + "/rest/index";
	static String BULK_URL = BASE_URL + "/rest/bulk";
	static String DELETE_URL = BASE_URL + "/rest/delete";
	static String SUGGEST_URL = BASE_URL + "/rest/suggest/";
	
	static final String _id = "1";
	
	@Test
	public void test_index() throws Exception {
		JSONObject row = new JSONObject();
		row.put("mid", 11);
		row.put("id", 112);
		row.put("title", "片名:楚汉传奇;别名:楚汉/楚汉志/项羽と刘邦;导演:高希希,汪海林,阎刚;主演:尤勇、杨立新、陈道明、何润东、段奕宏、秦岚、李依晓;上映时间:2012");
		
		INDEX_URL += "?index=" + INDEX + "&_id=" + _id;
		
		String resp = HttpRequest.post(INDEX_URL , row.toJSONString(),true);
		System.out.println("resp=" + resp);
		assertTrue(!JSON.parseObject(resp).getBooleanValue("error"));
	}
	
	@Test
	public void test_bulk() throws Exception {
		JSONObject row = new JSONObject();
		row.put("mid", 11);
		row.put("_id", _id);
		row.put("id", 112);
		row.put("title", "片名:楚汉传奇;别名:楚汉/楚汉志/项羽と刘邦;导演:高希希,汪海林,阎刚;主演:尤勇、杨立新、陈道明、何润东、段奕宏、秦岚、李依晓;上映时间:2012");
		
		JSONArray array = new JSONArray();
		array.add(row);
		BULK_URL += "?index=" + INDEX;
		String resp = HttpRequest.post(BULK_URL , array.toJSONString(),true);
		System.out.println("resp=" + resp);
		assertTrue(!JSON.parseObject(resp).getBooleanValue("error"));
	}
	
	@Test
	public void testSearchGetAndFilter() throws UnsupportedEncodingException{
		String resp = Rest.searchGetAndFilter(BASE_URL + "/rest/search/");
		Assert.assertTrue("resp is null" , StringUtils.isNotBlank(resp));
		JSONObject json = JSON.parseObject(resp);
		logger.info("json={}",json);
		Assert.assertTrue(json.getLongValue("total") > 0);
		Assert.assertTrue(json.getLongValue("time") > 0);
		Assert.assertTrue(!json.getJSONArray("result").isEmpty());
	}
	
	@Test
	public void testSearchPost() throws UnsupportedEncodingException{
		String resp = Rest.searchPost(BASE_URL + "/rest/search/");
		Assert.assertTrue("resp is null" , StringUtils.isNotBlank(resp));
	}
	
	@Test
	public void testSearchPostFilter() throws UnsupportedEncodingException{
		String resp = Rest.searchPostFilter(BASE_URL + "/rest/search/");
		Assert.assertTrue("resp is null" , StringUtils.isNotBlank(resp));
	}
	
	@Test
	public void testSuggestSearch(){
		String resp = Rest.suggest(BASE_URL + "/rest/suggest/",
				"lagou","java");
		Assert.assertTrue("resp is null" , StringUtils.isNotBlank(resp));
	}
	
//	@Test
//	public void suggestBulk(){
//		JSONObject json = new JSONObject();
//		json.put("index", RestTest.SUGGEST_INDEX);
//		json.put("type", RestTest.SUGGEST_INDEX);
//		JSONArray array = new JSONArray();
//		array.add(row("baidu",1000));
//		array.add(row("google",2000));
//		array.add(row("taobao",2100));
//		json.put("array", array);
//		
//		String resp = HttpRequest.post(BULK_URL,array.toJSONString(),true);
//		Assert.assertTrue("resp is null" , StringUtils.isNotBlank(resp));
//	}

	private JSONObject row(String suggest,int count) {
		JSONObject one = new JSONObject();
		one.put("suggest", suggest);
		one.put("count", count);
		return one;
	}
	
	@Test
	public void test_delete() throws Exception {
		String resp = HttpRequest.get(DELETE_URL + "?index="+INDEX+"&_id="+_id);
		System.out.println("resp=" + resp);
		assertTrue(!JSON.parseObject(resp).getBooleanValue("error"));
	}
}
