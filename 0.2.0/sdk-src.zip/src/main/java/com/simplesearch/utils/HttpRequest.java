package com.simplesearch.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HttpRequest {

    static Logger logger = LoggerFactory.getLogger(HttpRequest.class);
    /**
     * 向指定URL发送GET方法的请求
     * 
     * @param url
     *            发送请求的URL
     * @param param
     *            请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return URL 所代表远程资源的响应结果
     */
	public static String get(String url) {
		logger.info("GET: ");
		logger.info("url={}",url);
        BufferedReader in = null;
        StringBuffer lines = new StringBuffer();
        
        try {
            in = doGet(url);
            String line = null;
			while ((line  = in.readLine()) != null) {
				lines.append(line);
    		}
            
        } catch (Throwable e) {
            System.out.println("sendGet发送GET请求出现异常！" + e);
            e.printStackTrace();
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        return lines.toString();
    }
	
//	public static Set<String> sendGetFilterProduct(String url) {
//        BufferedReader in = null;
//        try {
//            in = doGet(url);
//            return doFilterProduct(in);
//        } catch (Throwable e) {
//            System.out.println("sendGetFilterProduct发送GET请求出现异常！" + e + ",url=" + url);
////            e.printStackTrace();
//        } finally {
//            try {
//                if (in != null) {
//                    in.close();
//                }
//            } catch (Exception e2) {
//                e2.printStackTrace();
//            }
//        }
//        return null;
//    }

	static BufferedReader doGet(String url)
			throws MalformedURLException, IOException {
		BufferedReader in;
		logger.info("req: "+url);
		URL realUrl = new URL(url);
		// 打开和URL之间的连接
		HttpURLConnection connection = (HttpURLConnection) realUrl.openConnection();
		// 设置通用的请求属性
		connection.setRequestProperty("Accept-Charset", "utf-8");
		connection.setRequestProperty("accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
		connection.setRequestProperty("connection", "Keep-Alive");
		connection.setRequestProperty("user-agent",
		        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36");
		// 建立实际的连接
		connection.connect();
		logger.info("connection.getResponseCode()={}",connection.getResponseCode());
		// 获取所有响应头字段
//		Map<String, List<String>> map = connection.getHeaderFields();
		// 遍历所有的响应头字段
//		for (String key : map.keySet()) {
//		    System.out.println(key + "--->" + map.get(key));
//		}
		// 定义 BufferedReader输入流来读取URL的响应
		in = new BufferedReader(new InputStreamReader(
		        connection.getInputStream(),"utf-8"));
		return in;
	}

//	private static void doRecommend(JSONArray json, BufferedReader in)
//			throws IOException {
//		String line;
//		while ((line = in.readLine()) != null) {
//			String[] arr = line.split(",");
//			
//			JSONObject item = new JSONObject();
//			item.put("offerId", arr[0]);
//			item.put("ratio", Float.parseFloat(arr[1])/2.1);
//			json.add(item);
//		}
//	}
	
//	static Set<String> doFilterProduct(BufferedReader in) throws IOException {
//		StringBuffer buff = new StringBuffer();
//		String line;
//		while ((line = in.readLine()) != null) {
//			buff.append(line);
//		}
//		
//		String finalStr = buff.toString();
//		finalStr = finalStr.substring(finalStr.indexOf("{"), finalStr.lastIndexOf("}") + 1);
////		System.out.println("finalStr: " + finalStr);
//		JSONObject json = JSON.parseObject(finalStr);
//		JSONArray result = json.getJSONArray("result");
//		Set<String> ids = new HashSet<String>();
//		for(int i=0;i<result.size();i++){
//			JSONObject item = result.getJSONObject(i);
//			if(item.getBooleanValue("sellable")){
//				ids.add(String.valueOf(item.getIntValue("id")));
//			}
//		}
//		return ids;
//	}

    /**
     * 向指定 URL 发送POST方法的请求
     * 
     * @param url
     *            发送请求的 URL
     * @param param
     *            请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return 所代表远程资源的响应结果
     */
    public static String post(String url, String param,boolean applicationJson) {
        PrintWriter out = null;
        BufferedReader in = null;
        String result = "";
        try {
            URL realUrl = new URL(url);
            // 打开和URL之间的连接
            URLConnection conn = realUrl.openConnection();
            // 设置通用的请求属性
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            if(applicationJson){
            	conn.setRequestProperty("Content-Type", "application/json");
            }
            conn.setRequestProperty("user-agent",
                    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            // 发送POST请求必须设置如下两行
            conn.setDoOutput(true);
            conn.setDoInput(true);
            // 获取URLConnection对象对应的输出流
            out = new PrintWriter(conn.getOutputStream());
            // 发送请求参数
            if(StringUtils.isNotBlank(param)){
            	out.print(param);
            }
            // flush输出流的缓冲
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(
                    new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            System.out.println("发送 POST 请求出现异常！"+e);
            e.printStackTrace();
        }
        //使用finally块来关闭输出流、输入流
        finally{
            try{
                if(out!=null){
                    out.close();
                }
                if(in!=null){
                    in.close();
                }
            }
            catch(IOException ex){
                ex.printStackTrace();
            }
        }
        return result;
    }    
}