package com.simplesearch;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import com.simplesearch.dsl.BooleanQuery;
import com.simplesearch.dsl.FilterQuery;
import com.simplesearch.dsl.QueryBuilders;
import com.simplesearch.utils.HttpRequest;

public class Rest {
	
	public static String searchPostFilter(String url) throws UnsupportedEncodingException{
		StringBuffer params = fullParams();
		
		return HttpRequest.post(url,params.toString(),false);
	}

	public static String searchPost(String url) throws UnsupportedEncodingException{
		StringBuffer params = fullParams();
		
		return HttpRequest.post(url,params.toString(),false);
	}
	
	public static String searchGetAndFilter(String url) throws UnsupportedEncodingException{
		StringBuffer params = fullParams();
		
		return HttpRequest.get(url + "?" + params.toString());
	}

	private static String filter() {
		BooleanQuery queryBool = BooleanQuery.bool()
				.must(QueryBuilders.term("positionId", 2882011))
				.must(QueryBuilders.term("companyShortName", "INK 银客集团"))
				;
		String filter = FilterQuery.fq(queryBool).getFilter().toJSONString();
		return filter;
	}
	
	private static StringBuffer fullParams() throws UnsupportedEncodingException {
		StringBuffer params = new StringBuffer();
		params.append("alias=").append("lagou");	//required
		params.append("&query=").append("*");		//required
		params.append("&from=").append("0");
		params.append("&size=").append("15");
		params.append("&sort=").append("publisherId:desc,positionName:asc");
		params.append("&filter=").append(URLEncoder.encode(filter(),"UTF-8"));
		return params;
	}
	
	public static String suggest(String url,String index,String query){
		StringBuffer finalUrl = new StringBuffer(url);
		finalUrl.append("?");
		finalUrl.append("index=").append(index);	//required
		finalUrl.append("&query=").append(query);	//required
		String resp = HttpRequest.get(finalUrl.toString());
		return resp;
	}
}
