package com.simplesearch.dsl;

public enum SortEnum {
	asc , desc 
}
