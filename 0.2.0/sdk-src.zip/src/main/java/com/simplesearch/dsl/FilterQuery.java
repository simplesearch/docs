package com.simplesearch.dsl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

/**
 * es过滤器filter，一个filter只包含一个bool，但一个bool可以包含无数嵌套的bool
 * @author huangf
 *
 */
public class FilterQuery {
	
	JSONObject filter = new JSONObject();
	
	public FilterQuery(){
	}
	
	public FilterQuery(JSONObject filter){
		this.filter = filter;
	}
	
	/**
	 * 一个filterQuery只能添加一个顶级的BooleanQuery，多次添加也只会记录最后一次的添加行为
	 * @param bool
	 * @return
	 */
	public static FilterQuery fq(BooleanQuery bool){
		if(bool==null){
			throw new NullPointerException("bool is null");
		}
		FilterQuery f = new FilterQuery();
		f.filter.put("bool", bool.getBoolJson());
		return f;
	}
	
	/**
	 * 获取filter包含的顶级的bool
	 * @return
	 */
	public BooleanQuery getTopBool(){
		BooleanQuery newBool = BooleanQuery.json2bool(filter.getJSONObject("bool"));
		return newBool;
	}

	public JSONObject getFilter() {
		return filter;
	}

	/**
	 * 如果需要将FilterQuery转成字符串的json格式，需要调用toString方法，如果调用JSON.toJSONString(FilterQuery)这样，会多出一个topBool来
	 * BooleanQuery转也是一样的道理，其原因是这2个对象的特殊性，都是用static方法内部new的自己
	 */
	@Override
	public String toString() {
		String jsonStr = JSON.toJSONString(this);
		JSONObject json = JSON.parseObject(jsonStr);
		json.remove("topBool");
		return json.toJSONString();
	}
	
	
}
