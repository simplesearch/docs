package com.simplesearch.dsl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

/**
 * bool查询，提供must,must_not,should等原语，并且支持bool嵌套
 * @author huangf
 *
 */
public class BooleanQuery {
	private JSONObject boolJson = new JSONObject();
	
	private BooleanQuery(JSONObject json){
		if(json!=null){
			this.boolJson = json;
		}
	}
	
	public static BooleanQuery bool(){
		return new BooleanQuery(null);
	}
	
	/**
	 * json对象转换成BooleanQuery
	 * @param json
	 * @return
	 */
	public static BooleanQuery json2bool(JSONObject json){
		return new BooleanQuery(json);
	}
	
	public BooleanQuery must(JSONArray array){
		if(array!=null){
			getMust().addAll(array);
		}
		return this;
	}
	
	public BooleanQuery must(JSONObject json){
		if(json!=null){
			getMust().add(json);
		}
		return this;
	}
	
	/**
	 * womai-search的order用的solr的fq做filter，solr的多个fq之间是must关系，和es的此方法匹配
	 * @param bool
	 * @return
	 */
	public BooleanQuery must(BooleanQuery bool) {
		if(bool!=null){
			JSONObject jj =new JSONObject();
			jj.put("bool", bool.getBoolJson());
			getMust().add(jj);
		}
		return this;
	}
	
	public BooleanQuery must_not(JSONArray array){
		if(array!=null){
			getMustNot().addAll(array);
		}
		return this;
	}
	
	public BooleanQuery must_not(JSONObject json){
		if(json!=null){
			getMustNot().add(json);
		}
		return this;
	}
	
	public BooleanQuery must_not(BooleanQuery bool) {
		if(bool!=null){
			JSONObject jj =new JSONObject();
			jj.put("bool", bool.getBoolJson());
			getMustNot().add(jj);
		}
		return this;
	}
	
	public BooleanQuery should(JSONArray array){
		if(array!=null){
			getShould().addAll(array);
		}
		return this;
	}
	
	public BooleanQuery should(JSONObject json){
		if(json!=null){
			getShould().add(json);
		}
		return this;
	}
	
	public BooleanQuery should(BooleanQuery bool) {
		if(bool!=null){
			JSONObject jj =new JSONObject();
			jj.put("bool", bool.getBoolJson());
			getShould().add(jj);
		}
		return this;
	}
	
	/**
	 * get
	 * @return
	 */
	
	public JSONArray getMust(){
		if(!boolJson.containsKey("must")){
			boolJson.put("must", new JSONArray());
		}
		return boolJson.getJSONArray("must");
	}
	
	public JSONArray getMustNot(){
		if(!boolJson.containsKey("must_not")){
			boolJson.put("must_not", new JSONArray());
		}
		return boolJson.getJSONArray("must_not");
	}
	
	public JSONArray getShould(){
		if(!boolJson.containsKey("should")){
			boolJson.put("should", new JSONArray());
		}
		return boolJson.getJSONArray("should");
	}

	public JSONObject getBoolJson() {
		return boolJson;
	}

	public void addFilter(JSONObject filterBool) {
		if(filterBool!=null){
			this.boolJson.put("filter", filterBool);
		}
	}

	@Override
	public String toString() {
		return boolJson.toJSONString();
	}
	
	
}
