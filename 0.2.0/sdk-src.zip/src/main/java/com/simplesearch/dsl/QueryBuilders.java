package com.simplesearch.dsl;

import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections4.CollectionUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

/**
 * 提供esapi rest的search（整体），term（部分）等的检索
 * @author huangf
 *
 */
public class QueryBuilders {

	/**
	 * create final search
	 * @param request
	 * @return
	 */
	public static String search(SearchRequest request) {
		JSONObject json = new JSONObject();
		JSONObject query = new JSONObject();
		
		BooleanQuery bool = BooleanQuery.bool().must(request.getQueryBool());
		
		if(request.getFilterBool()!=null && !request.getFilterBool().getFilter().isEmpty()){
			bool.addFilter(request.getFilterBool().getFilter());
		}
		query.put("bool", bool.getBoolJson());
		json.put("query", query);
		json.put("from", request.getFrom());
		json.put("size", request.getSize());
		if(request.getFields()!=null && request.getFields().size() > 0){
			json.put("stored_fields", request.getFields());
		}
		json.put("explain", request.isExplain());
		
		if(CollectionUtils.isNotEmpty(request.getHighlightFields())){
			JSONObject highlightJson = new JSONObject();
			JSONArray pre_tags = new JSONArray();
			JSONArray post_tags = new JSONArray();
			JSONObject fieldsJson = new JSONObject();
			pre_tags.add("<font color='red'>");	//start lable
			post_tags.add("</font>");	//end lable
			
			for(String field : request.getHighlightFields()){
				fieldsJson.put(field, new JSONObject());
			}
			
			highlightJson.put("pre_tags", pre_tags);
			highlightJson.put("post_tags", post_tags);
			highlightJson.put("fields", fieldsJson);
			json.put("highlight", highlightJson);
		}
		
		JSONArray sort = sort(request.getSortFields());
		if(sort!=null && !sort.isEmpty()){
			json.put("sort", sort(request.getSortFields()));
		}
		
		if(request.getRescore()!=null){
			json.put("rescore", request.getRescore());
		}
		
//		json.put("aggs", aggs);
		
		return json.toJSONString();
	}
	
	public static String count(SearchRequest request) {
		JSONObject json = new JSONObject();
		JSONObject query = new JSONObject();
		
		BooleanQuery bool = BooleanQuery.bool().must(request.getQueryBool());
		
		if(request.getFilterBool()!=null && !request.getFilterBool().getFilter().isEmpty()){
			bool.addFilter(request.getFilterBool().getFilter());
		}
		query.put("bool", bool.getBoolJson());
		json.put("query", query);
		
		return json.toJSONString();
	}
	
	public static JSONArray sort(Map<String, SortEnum> fields) {
		if(fields==null || fields.isEmpty()){
			return null;
		}
		
		JSONArray json = new JSONArray();
		for(Iterator<Entry<String, SortEnum>> it = fields.entrySet().iterator();
				it.hasNext();){
			Entry<String, SortEnum> entry = it.next();
			JSONObject item = new JSONObject();
			JSONObject order = new JSONObject();
			item.put(entry.getKey(), order);
			order.put("order", entry.getValue().name());
			json.add(item);
		}
		return json;
	}

	public static JSONObject term(String field, Object value) {
		JSONObject term = new JSONObject();
		JSONObject fieldValue = new JSONObject();
		fieldValue.put(field, value);
		term.put("term", fieldValue);
		return term;
	}

	public static JSONObject wildcard(String field, Object value) {
		JSONObject wildcard = new JSONObject();
		JSONObject fieldValue = new JSONObject();
		fieldValue.put(field, value);
		wildcard.put("wildcard", fieldValue);
		return wildcard;
	}

	public static JSONObject prefix(String field, Object value) {
		JSONObject prefix = new JSONObject();
		JSONObject fieldValue = new JSONObject();
		fieldValue.put(field, value);
		prefix.put("prefix", fieldValue);
		return prefix;
	}
	
	public static JSONObject querystring(String qs) {
		JSONObject querystringJson = new JSONObject();
		JSONObject json = new JSONObject();
		json.put("query", qs);
		querystringJson.put("query_string", json);
		return querystringJson;
	}

	public static JSONObject range(String field, Number start, Number end) {
		return range0(field, start, end, false, false);
	}
	
	public static JSONObject range(String field, Number start, Number end,boolean left, boolean right) {
		return range0(field, start, end, left, right);
	}

	public static JSONObject range(String field, Date start, Date end,
			boolean left, boolean right) {
		return range0(field, start == null ? null : start.getTime(), end == null ? null : end.getTime(), left, right);
	}

	private static JSONObject range0(String field, Number start, Number end,
			boolean left, boolean right) {
		JSONObject range = new JSONObject();
		JSONObject fieldJson = new JSONObject();
		JSONObject value = new JSONObject();
		range.put("range", fieldJson);
		fieldJson.put(field, value);
		
		if(start!=null){
			if(left){
				value.put("gte", start.longValue());
			}else{
				value.put("gt", start.longValue());
			}
		}
		if(end!=null){
			if(right){
				value.put("lte", end.longValue());
			}else{
				value.put("lt", end.longValue());
			}
		}
		return range;
	}
}
