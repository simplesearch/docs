package com.simplesearch.dsl;

import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONObject;

public class SearchRequest {

	int from;
	int size = 40;
	BooleanQuery queryBool;
	FilterQuery filterBool;
	List<String> fields;
	boolean explain;
	Map<String, SortEnum> sortFields;
	List<String> highlightFields;
	JSONObject rescore;
	
	public SearchRequest(BooleanQuery queryBool) {
		this(0,40,queryBool,null,null,false,null,null);
	}
	
	public SearchRequest(int from, int size, BooleanQuery queryBool) {
		this(from,size,queryBool,null,null,false,null,null);
	}
	
	public SearchRequest(int from, int size, BooleanQuery queryBool, FilterQuery filterBool,
			List<String> fields,Map<String, SortEnum> sortFields,List<String> highlightFields) {
		this(from,size,queryBool,filterBool,fields,false,sortFields,highlightFields);
	}
	
	public SearchRequest(int from, int size, BooleanQuery queryBool, FilterQuery filterBool,
			List<String> fields,boolean explain,Map<String, SortEnum> sortFields,List<String> highlightFields) {
		this.from = from;
		this.size = size;
		this.queryBool = queryBool;
		this.filterBool = filterBool;
		this.fields = fields;
		this.explain = explain;
		this.sortFields = sortFields;
		this.highlightFields = highlightFields;
	}
	public int getFrom() {
		return from;
	}
	public void setFrom(int from) {
		this.from = from;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public BooleanQuery getQueryBool() {
		return queryBool;
	}
	public void setQueryBool(BooleanQuery queryBool) {
		this.queryBool = queryBool;
	}
	public FilterQuery getFilterBool() {
		return filterBool;
	}
	public void setFilterBool(FilterQuery filterBool) {
		this.filterBool = filterBool;
	}
	public List<String> getFields() {
		return fields;
	}
	public void setFields(List<String> fields) {
		this.fields = fields;
	}
	public boolean isExplain() {
		return explain;
	}
	public void setExplain(boolean explain) {
		this.explain = explain;
	}
	public Map<String, SortEnum> getSortFields() {
		return sortFields;
	}
	public void setSortFields(Map<String, SortEnum> sortFields) {
		this.sortFields = sortFields;
	}

	public List<String> getHighlightFields() {
		return highlightFields;
	}

	public void setHighlightFields(List<String> highlightFields) {
		this.highlightFields = highlightFields;
	}

	public JSONObject getRescore() {
		return rescore;
	}

	public void setRescore(JSONObject rescore) {
		this.rescore = rescore;
	}
	
}
